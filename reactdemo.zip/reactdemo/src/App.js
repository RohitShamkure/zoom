import logo from './logo.svg';
import './App.css';
import Header from './components/Header';
import Home from './components/Home';
import React from 'react';
import { Button } from 'reactstrap';
import Course from './components/Course';
import AllCourse from './components/AllCourses';
//import Home from './components/Home';
//import { ToastContainer, toast } from 'react-toastify';
//import 'react-toastify/dist/ReactToastify.css';

function App() {
  return (
      <div>
        {/* <Button outline color="primary">First React Button </Button>
        <Header />
        <Home /> */}
        {/* <Course /> */}
       <AllCourse />
      </div>
        );
      }
      
      export default App;












    
//     <div>
//       <h1>This is my react js application</h1>
//       <Header name="Rohit Shamkure" title="Btech" />
//       <hr />
//       <Header name="Rohit Shamkure" title="Btech" />
// </div>











    /* // <div className="App">
    //   <header className="App-header">
    //     <img src={logo} className="App-logo" alt="logo" />
    //     <p>
    //       Edit <code>src/App.js</code> and save to reload.
    //     </p>
    //     <a
    //       className="App-link"
    //       href="https://reactjs.org"
    //       target="_blank"
    //       rel="noopener noreferrer"
    //     >
    //       Learn React
    //     </a>
    //   </header>
     //   </div> */
     
//       );
// }

// export default App;
