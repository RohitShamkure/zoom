// import React from 'react';



// function Header({name,title}){
//     return ( 
//         <div style={{background:"blue",padding:20,width:400}}>
//               <h1>This is header component</h1>
//               <h2>{name}</h2>
//               <h3>{title}</h3>
//         </div>
    
// );
// }

// export default Header;

  

