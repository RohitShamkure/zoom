import React from 'react';

function Header({name, title}){
    return(
        <div>
            <h1>Welcome to courses Application</h1>
        </div>
    );
}

export default Header;