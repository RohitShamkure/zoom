import React from 'react';
//import {Jumbotron,Container,Button} from "reactstrap";
import { Button } from 'reactstrap';

const Home=()=>{
    return(
        <div>

            
                <h1>Transflower Academy</h1>
                     <Button color='primary'>Start Using</Button>
                
           
        </div>
    )
};

export default Home;