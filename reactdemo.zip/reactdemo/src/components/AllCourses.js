import React, { useState } from "react"
import Course from "./Course"


const AllCourse=()=>{

    const [courses,setCourses]=useState([
        {title:"Python Course",description:"Not in syllabus"},
        {title:"Java Course",description:"In syllabus"},
        {title:"NodeJs Course",description:"ServerSide Technology"}
    ]);

    return(
        <div>
            <h3>All Course</h3>
            <p>List of Courses</p>
            {
                courses.length>0? 
                courses.map((item)=> <Course course={item}/>)
                : "No Courses"

                
            }

        </div>
    );
}
export default AllCourse;
 